#include "doublelist.h"
/*
DoubleList::DoubleList()
{

}
*/
